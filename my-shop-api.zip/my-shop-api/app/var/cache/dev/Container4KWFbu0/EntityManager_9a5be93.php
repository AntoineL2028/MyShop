<?php

namespace Container4KWFbu0;
include_once \dirname(__DIR__, 4).'/vendor/doctrine/persistence/lib/Doctrine/Persistence/ObjectManager.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder5486c = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializerd22db = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicPropertiesdc0df = [
        
    ];

    public function getConnection()
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'getConnection', array(), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'getMetadataFactory', array(), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'getExpressionBuilder', array(), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'beginTransaction', array(), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->beginTransaction();
    }

    public function getCache()
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'getCache', array(), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->getCache();
    }

    public function transactional($func)
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'transactional', array('func' => $func), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'wrapInTransaction', array('func' => $func), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'commit', array(), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->commit();
    }

    public function rollback()
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'rollback', array(), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'getClassMetadata', array('className' => $className), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'createQuery', array('dql' => $dql), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'createNamedQuery', array('name' => $name), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'createQueryBuilder', array(), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'flush', array('entity' => $entity), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'clear', array('entityName' => $entityName), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->clear($entityName);
    }

    public function close()
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'close', array(), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->close();
    }

    public function persist($entity)
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'persist', array('entity' => $entity), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'remove', array('entity' => $entity), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'refresh', array('entity' => $entity), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'detach', array('entity' => $entity), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'merge', array('entity' => $entity), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'getRepository', array('entityName' => $entityName), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'contains', array('entity' => $entity), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'getEventManager', array(), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'getConfiguration', array(), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'isOpen', array(), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'getUnitOfWork', array(), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'getProxyFactory', array(), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'initializeObject', array('obj' => $obj), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'getFilters', array(), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'isFiltersStateClean', array(), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'hasFilters', array(), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return $this->valueHolder5486c->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializerd22db = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder5486c) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder5486c = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder5486c->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, '__get', ['name' => $name], $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        if (isset(self::$publicPropertiesdc0df[$name])) {
            return $this->valueHolder5486c->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder5486c;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder5486c;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, '__set', array('name' => $name, 'value' => $value), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder5486c;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder5486c;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, '__isset', array('name' => $name), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder5486c;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder5486c;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, '__unset', array('name' => $name), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder5486c;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder5486c;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, '__clone', array(), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        $this->valueHolder5486c = clone $this->valueHolder5486c;
    }

    public function __sleep()
    {
        $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, '__sleep', array(), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;

        return array('valueHolder5486c');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializerd22db = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializerd22db;
    }

    public function initializeProxy() : bool
    {
        return $this->initializerd22db && ($this->initializerd22db->__invoke($valueHolder5486c, $this, 'initializeProxy', array(), $this->initializerd22db) || 1) && $this->valueHolder5486c = $valueHolder5486c;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder5486c;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder5486c;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
